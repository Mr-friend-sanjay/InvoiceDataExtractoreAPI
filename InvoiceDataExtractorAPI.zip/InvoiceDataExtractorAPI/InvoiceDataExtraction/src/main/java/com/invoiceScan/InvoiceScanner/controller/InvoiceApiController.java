package com.invoiceScan.InvoiceScanner.controller;



import com.invoiceScan.InvoiceScanner.model.InvoiceData;
//import org.opencv.core.*;
//import org.opencv.imgproc.Imgproc;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.core.CvType;
import org.opencv.core.Point;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;





@RestController
@RequestMapping("/api")
class InvoiceApiController {
    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.setProperty("jna.library.path", "C:\\Users\\sanja\\Downloads\\Tess4J-3.4.8-src\\Tess4J\\dist\\tess4j-3.4.0");
    }

    @PostMapping("/upload")
    public ResponseEntity<InvoiceData> uploadInvoice(@RequestParam("image") MultipartFile image) {
        try {
            Mat matImage = convertMultipartFileToMat(image);
            Mat preprocessedImage = preprocessImage(matImage);
            String extractedText = performOCR(preprocessedImage);
            InvoiceData invoiceData = extractInvoiceData(extractedText);
            return ResponseEntity.ok(invoiceData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private Mat convertMultipartFileToMat(MultipartFile image) {
        try {
            byte[] bytes = image.getBytes();
            BufferedImage bufferedImage = ImageIO.read(image.getInputStream());
            int height = bufferedImage.getHeight();
            int width = bufferedImage.getWidth();
            Mat mat = new Mat(height, width, CvType.CV_8UC1);
            mat.put(0, 0, bytes);

            System.out.println("mat" + mat);
            return mat;
        } catch (IOException e) {
            e.printStackTrace();
            return new Mat();
        }
    }

    private Mat preprocessImage(Mat matImage) {
        Mat preprocessedImage = new Mat();

        // Check if the image is already grayscale
        if (matImage.channels() > 1) {
            Imgproc.resize(matImage, preprocessedImage, new Size(800, 600));
            Imgproc.cvtColor(preprocessedImage, preprocessedImage, Imgproc.COLOR_BGR2GRAY);
        } else {
            // If it's already grayscale, no need for conversion
            preprocessedImage = matImage.clone();
        }

        System.out.println("preprocessedImage::" + preprocessedImage);
        return preprocessedImage;
    }


    private String performOCR(Mat image) {
        ITesseract tesseract = new Tesseract();
        try {
            System.out.println("performOCR::" + tesseract.doOCR(convertMatToBufferedImage(image)));
            return tesseract.doOCR(convertMatToBufferedImage(image));
        } catch (TesseractException e) {
            System.err.println("Error during OCR: " + e.getMessage());
            return "";
        }
    }

    private BufferedImage convertMatToBufferedImage(Mat mat) {
        int type = mat.channels() > 1 ? BufferedImage.TYPE_3BYTE_BGR : BufferedImage.TYPE_BYTE_GRAY;
        BufferedImage image = new BufferedImage(mat.cols(), mat.rows(), type);
        mat.get(0, 0, ((DataBufferByte) image.getRaster().getDataBuffer()).getData());
        System.out.println("image::" + image);
        return image;
    }

    private InvoiceData extractInvoiceData(String extractedText) {
        String invoiceNumber = extractInvoiceNumber(extractedText);
        return new InvoiceData(invoiceNumber, null, null);
    }

    private String extractInvoiceNumber(String extractedText) {
        String pattern = "Invoice Number: (\\w+)";
        Pattern regexPattern = Pattern.compile(pattern);
        Matcher matcher = regexPattern.matcher(extractedText);

        if (matcher.find()) {
            return matcher.group(1);
        }
        System.out.println("String pattern :: " +  pattern);
        return "";
    }
}




